Type  Shapefile

Tags  Archeology, GIS, Remote Sensing, Old maps, Topographic maps

Summary
Spatial data representing the course of Roman roads based on old topographic maps.

Description
The file entitled “Roman Imperial Roads” contains polyline vector data representing the course of Roman Imperial Roads in the research area. It was created using old topographic maps that had been georeferenced. Due to the imperfection of the cartometric sources, location errors can be up to several hundred meters. The native spatial reference of the dataset is WGS-84 (EPSG: 4326). The data contain information about their source as an attribute.

The dataset is a result of the project entitled “Travel and Mobility in Hellenistic and Early Roman Palestine,” which is financed by the National Science Centre in Poland (grant no. UMO-2020/38/E/HS3/00031).

Credits
Jagiellonian University

Use limitations
There are no access and use limitations for this item.

Extent
There is no extent for this item.

Scale Range
Maximum (zoomed in)  	1:5,000
Minimum (zoomed out)  	1:150,000,000
